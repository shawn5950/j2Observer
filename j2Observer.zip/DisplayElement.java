package src;

public interface DisplayElement  {


  public void display();
 
  
}
